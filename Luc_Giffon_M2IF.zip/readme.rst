Future ameliorations
--------------------

- Generate reports about statistics of execution (graphs)

